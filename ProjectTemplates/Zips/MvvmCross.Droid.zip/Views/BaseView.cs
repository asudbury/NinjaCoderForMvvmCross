// --------------------------------------------------------------------------------------------------------------------
// <summary>
//    Defines the BaseView type.
// </summary>
// --------------------------------------------------------------------------------------------------------------------
namespace $safeprojectname$.Views
{
    using Cirrious.MvvmCross.Droid.Views;

    /// <summary>
    ///    Defines the BaseView type.
    /// </summary>
    public abstract class BaseView : MvxActivity
    {
    }
}
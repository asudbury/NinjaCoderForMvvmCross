// --------------------------------------------------------------------------------------------------------------------
// <summary>
//    Defines the ErrorDisplayer type.
// </summary>
// --------------------------------------------------------------------------------------------------------------------
namespace $safeprojectname$
{
    using Android.App;
    using Cirrious.CrossCore;
    using Cirrious.CrossCore.Droid.Platform;

    using #coreproject#.ApplicationObjects;

    /// <summary>
    /// Defines the ErrorDisplayer type.
    /// </summary>
    public class ErrorDisplayer
    {
        /// <summary>
        /// Initializes this instance.
        /// </summary>
        public void Initialize()
        {
            IErrorSource errorSource = Mvx.Resolve<IErrorSource>();
            errorSource.ErrorReported += (sender, args) => this.ShowError(args.Title, args.Message);
        }

        /// <summary>
        /// Shows the error.
        /// </summary>
        /// <param name="title">The title.</param>
        /// <param name="message">The message.</param>
        private void ShowError(
            string title,
            string message)
        {
            Activity activity = Mvx.Resolve<IMvxAndroidCurrentTopActivity>().Activity;

            if (activity != null)
            {
                AlertDialog alertDialog = new AlertDialog.Builder(activity).Create();

                alertDialog.SetTitle(title);
                alertDialog.SetMessage(message);
                alertDialog.SetButton("OK", (sender, args) => { });
                alertDialog.Show();
            }
        }
    }
}
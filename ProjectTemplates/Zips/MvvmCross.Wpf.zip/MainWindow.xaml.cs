﻿// --------------------------------------------------------------------------------------------------------------------
// <summary>
//    Defines the MainWindow type.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace $safeprojectname$
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow
    {
        public MainWindow()
        {
            this.InitializeComponent();
        }
    }
}

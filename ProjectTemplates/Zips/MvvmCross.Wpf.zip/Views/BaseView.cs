﻿// --------------------------------------------------------------------------------------------------------------------
// <summary>
//    Defines the BaseView type.
// </summary>
// --------------------------------------------------------------------------------------------------------------------
namespace $safeprojectname$.Views
{
    /// <summary>
    ///  Defines the BaseView type.
    /// </summary>
    public abstract class BaseView
    {
    }
}

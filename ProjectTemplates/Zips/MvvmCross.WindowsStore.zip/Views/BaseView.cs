﻿// --------------------------------------------------------------------------------------------------------------------
// <summary>
//    Defines the BaseView type.
// </summary>
// --------------------------------------------------------------------------------------------------------------------
    
namespace $safeprojectname$.Views
{
    using $safeprojectname$.Common;

    /// <summary>
    ///  Defines the BaseView type.
    /// </summary>
    public class BaseView : LayoutAwarePage
    {
    }
}

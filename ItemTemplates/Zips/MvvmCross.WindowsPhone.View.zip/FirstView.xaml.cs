// --------------------------------------------------------------------------------------------------------------------
// <summary>
//    Defines the $safeitemname$.xaml type.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace $rootnamespace$
{
    /// <summary>
    ///    Defines the $safeitemname$.xaml type.
    /// </summary>
    public partial class $safeitemname$ 
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="$safeitemname$"/> class.
        /// </summary>
        public $safeitemname$() 
        {
            InitializeComponent();
        }
    }
}
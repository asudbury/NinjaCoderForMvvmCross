﻿// --------------------------------------------------------------------------------------------------------------------
// <summary>
//    Defines the $safeitemname$ type.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace $rootnamespace$
{
    /// <summary>
    /// Interaction logic for $safeitemname$.xaml
    /// </summary>
    public partial class $safeitemname$
    {
        public $safeitemname$()
        {
            this.InitializeComponent();
        }
    }
}

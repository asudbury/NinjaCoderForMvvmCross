﻿// --------------------------------------------------------------------------------------------------------------------
// <summary>
//    Defines the FirstView type.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace WpfTemplate.Views
{
    using Cirrious.MvvmCross.Wpf.Views;

    /// <summary>
    /// Interaction logic for FirstView.xaml
    /// </summary>
    public partial class FirstView
    {
        public FirstView()
        {
            this.InitializeComponent();
        }
    }
}

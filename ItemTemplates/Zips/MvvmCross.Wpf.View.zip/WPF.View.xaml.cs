﻿
// --------------------------------------------------------------------------------------------------------------------
// <summary>
//    Defines the $safeitemrootname$ type.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace $rootnamespace$
{
    /// <summary>
    /// Interaction logic for $safeitemrootname$.xaml
    /// </summary>
    public partial class MvvmCross 
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="$safeitemrootname$"/> class.
        /// </summary>
        public MvvmCross()
        {
            this.InitializeComponent();
        }
    }
}


﻿// --------------------------------------------------------------------------------------------------------------------
// <summary>
//    Defines the Start type.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace $safeprojectname$
{
    using System;

    /// <summary>
    ///   Defines the Start type.
    /// </summary>
    public class Start
    {
        /// <summary>
        /// Mains this instance.
        /// </summary>
        [STAThread]
        static void Main()
        {
        }
    }
}

﻿// --------------------------------------------------------------------------------------------------------------------
// <summary>
//    Defines the $safeitemname$.xaml type.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace $rootnamespace$
{
    /// <summary>
    /// A basic page that provides characteristics common to most applications.
    /// </summary>
    public sealed partial class $safeitemname$
    {
        public $safeitemname$()
        {
            this.InitializeComponent();
        }
    }
}
// --------------------------------------------------------------------------------------------------------------------
// <summary>
//    Defines the $safeitemname$ type.
// </summary>
// --------------------------------------------------------------------------------------------------------------------
namespace CoreTemplates.Bootstrap
{
    using Cirrious.CrossCore.Plugins;

    /// <summary>
    /// Defines the $safeitemname$ type.
    /// </summary>
    public class Plugin
        : MvxPluginBootstrapAction<Cirrious.MvvmCross.Plugins.All.PluginLoader>
    {
    }
}
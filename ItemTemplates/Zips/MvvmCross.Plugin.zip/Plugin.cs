// --------------------------------------------------------------------------------------------------------------------
// <summary>
//    Defines the $safeitemname$ type.
// </summary>
// --------------------------------------------------------------------------------------------------------------------
namespace $rootnamespace$
{
    using Cirrious.CrossCore.Plugins;

    /// <summary>
    /// Defines the $safeitemname$ type.
    /// </summary>
    public class $safeitemname$
        : MvxPluginBootstrapAction<Cirrious.MvvmCross.Plugins.#PlaceHolder#.PluginLoader>
    {
    }
}
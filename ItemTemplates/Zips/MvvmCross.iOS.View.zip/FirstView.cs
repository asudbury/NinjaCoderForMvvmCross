// --------------------------------------------------------------------------------------------------------------------
// <summary>
//    Defines the $safeitemname$ type.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace $rootnamespace$
{
    using System.Drawing;

    using Cirrious.MvvmCross.Binding.BindingContext;

    using Core.ViewModels;

    using MonoTouch.UIKit;
    using MonoTouch.Foundation;

    /// <summary>
    /// Defines the $safeitemname$ type.
    /// </summary>
    [Register("$safeitemname$")]
    public class $safeitemname$ : BaseView
    {
        /// <summary>
        /// Views the did load.
        /// </summary>
        /// <summary>
        /// Called when the View is first loaded
        /// </summary>
        public override void ViewDidLoad()
        {
            base.ViewDidLoad();

            UILabel uiLabel = new UILabel(new RectangleF(0, 0, 320, 50));
            View.AddSubview(uiLabel);
            UITextField uiTextField = new UITextField(new RectangleF(0, 50, 320, 50));
            View.AddSubview(uiTextField);

            var set = this.CreateBindingSet<$safeitemname$, FirstViewModel>();
            set.Bind(uiLabel).To(vm => vm.MyProperty);
            set.Bind(uiTextField).To(vm => vm.MyProperty);
            set.Apply();
        }
    }
}